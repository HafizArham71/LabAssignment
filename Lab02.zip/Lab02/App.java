public class App {
    public static void main(String[] args) {
        // Using default constructor and setters
        Product p1 = new Product();
        p1.setProductName("Glassess");
        p1.setProductId(1534);
        p1.setPrice(7000);
        p1.setStockAvail(true);

        // Using parameterized constructor
        Product p2 = new Product("Watch", 1078, 500, true);

        // Printing p1 details using getters
        System.out.println(p1.getProductName());
        System.out.println(p1.getProductId());
        System.out.println(p1.getPrice());
        System.out.println(p1.getStockAvail());

	// Display both products
        p1.display();
        p2.display();

        // Changing p1 details
        p1.setProductName("Clock");
        p1.setProductId(1234);
        p1.setPrice(200);
        p1.setStockAvail(false);

	// Display both products
        p1.display();
        p2.display();

        // Printing p2 details using getters
        System.out.println(p2.getProductName());
        System.out.println(p2.getProductId());
        System.out.println(p2.getPrice());
        System.out.println(p2.getStockAvail());

        // Changing p2 details
        p2.setProductName("Clock");
        p2.setProductId(1234);
        p2.setPrice(200);
        p2.setStockAvail(false);

        // Display both products
        p1.display();
        p2.display();
    }
}
