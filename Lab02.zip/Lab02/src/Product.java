public class Product {
    private String productName;
    private int productId;
    private double price;
    private boolean stockAvail;

    // Default constructor
    public Product() {
    }

    // Parameterized constructor
    public Product(String productName, int productId, double price, boolean stockAvail) {
        this.productName = productName;
        this.productId = productId;
        this.price = price;
        this.stockAvail = stockAvail;
    }

    // Getters 
    public String getProductName() {
        return productName;
    }

    public int getProductId() {
        return productId;
    }

    public double getPrice() {
        return price;
    }

    public boolean getStockAvail() {
        return stockAvail;
    }

    // Setters 
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStockAvail(boolean stockAvail) {
        this.stockAvail = stockAvail;
    }

    public void display() {
        System.out.println("ProductName: " + this.productName);
        System.out.println("ProductId: " + this.productId);
        System.out.println("ProductPrice: " + this.price);
        System.out.println("ProductAvail: " + this.stockAvail);
    }
}
